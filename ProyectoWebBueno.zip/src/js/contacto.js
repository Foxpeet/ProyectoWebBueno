function enviarContacto(event) {
    event.preventDefault();

    window.location.href = "../src/confirmacion-contacto.html"
}
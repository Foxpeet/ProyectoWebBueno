function mensajeOut() {
    document.getElementById("cerrarsesion").style.display = "block";
}

function irlanding() {
    location.href = "../src/index.html"
}
function mensajeOut() {
    document.getElementById("cerrarsesion").style.display = "block";
}

function irlanding() {
    location.href = "../index.html"
}